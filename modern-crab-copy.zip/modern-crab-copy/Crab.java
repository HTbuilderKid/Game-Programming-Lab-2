import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

public class Crab extends Actor
{
    private GreenfootImage image;
    
    public Crab()
    {
        image = new GreenfootImage("crab.png");
        setImage(image);
    }
        
    public void act()
    {
        checkKeypress();
        checkCollision();
        move(5);
        switchImage();
    }
    
        private void checkCollision() 
    {
        Bomb a = (Bomb) getOneIntersectingObject(Bomb.class);
        if (a != null) {
            getWorld().removeObject(this);
        }
    }
    
    public void switchImage()
    {
        if (getImage() == image) 
        {
            setImage(image);
        }
    }
            
    public void checkKeypress()
    {
        if (Greenfoot.isKeyDown("left")) 
        {
            turn(-4);
        }
        if (Greenfoot.isKeyDown("right")) 
        {
            turn(4);
        }
    }
}