import greenfoot.*;  // imports Actor, World, Greenfoot, GreenfootImage

public class CrabWorld extends World
{
    /**
     * Create a new world with 10x10 cells and
     * with a cell size of 60x60 pixels.
     */
    public CrabWorld() 
    {
        super(560, 560, 1);
        setPaintOrder(Crab.class, Bomb.class);
    }

    /**
     * Populate the world with a fixed scenario of wombats and leaves.
     */    
    public void populate()
    {
        addObject(new Crab(), 7, 1);
        randomBombs(10);
    }
    
    public void randomBombs(int howMany)
    {
        for (int i=0; i<howMany; i++) {
            Bomb bomb = new Bomb();
            int x = Greenfoot.getRandomNumber(getWidth());
            int y = Greenfoot.getRandomNumber(getHeight());
            addObject(bomb, x, y);
        }
    }
}